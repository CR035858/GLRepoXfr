
public class ArithmeticExceptionSample {

	public void calculate(int num1,int num2)
	{
		int result=0;
		System.out.println("We are in arith function");
		System.out.println("About to perform arith activity...");
		try
		{	
			result = num1 / num2;
			System.out.println("The result is "+result);
		}
		catch(ArithmeticException ae)
		{
			System.out.println(ae);
		}
		finally
		{
			System.out.println("Anyways we are here....");
		}
		
		System.out.println("Finished arith activity...");
		System.out.println("Leaving calculate function...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArithmeticExceptionSample aes = new ArithmeticExceptionSample();
		System.out.println("We are about to invoke arith function...");
	/*	try
		{*/
		aes.calculate(100, 50);
		aes.calculate(100, 10);
		aes.calculate(200, 0);
		aes.calculate(300, 50);
		aes.calculate(400, 50);
	/*	}
		catch(ArithmeticException ae)
		{
			System.out.println(ae);
		}*/
		System.out.println("We finished invoking arith function...");
	}

}
