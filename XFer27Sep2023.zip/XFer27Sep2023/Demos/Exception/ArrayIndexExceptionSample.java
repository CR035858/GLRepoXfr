
public class ArrayIndexExceptionSample {

	public void manipulateArray()
	{
		System.out.println("We are in array manipulation function");
		int arr[] = new int[10];
		try
		{
			for(int i=0;i<11;i++)
			{
            arr[i] = (i + 1) * 10;
				System.out.println("The Element is "+arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			aie.printStackTrace();
		}
		System.out.println("We are leaving array manipulation function");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are in main...");
		ArrayIndexExceptionSample aes = new ArrayIndexExceptionSample();
		aes.manipulateArray();
		System.out.println("We are exiting main...");

	}

}
