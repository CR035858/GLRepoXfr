
public class MyExceptionClass {

	public void calculate(int numer,int denom)
	{
		int result=0;
		System.out.println("Entered Calculate function ....");
		try
		{
        result = numer / denom;
		}
		catch(ArithmeticException ae)
		{
			ae.printStackTrace();
		}
		System.out.println("The REsult is "+result);
		System.out.println("Leaving Calculate Function ....");
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.out.println("In the Main...");
			System.out.println("About to call Calculate....");
			MyExceptionClass mec = new MyExceptionClass();
		/*	try
			{*/
				mec.calculate(200, 50);
				mec.calculate(500, 100);
				mec.calculate(500, 0);
				mec.calculate(200, 50);
				mec.calculate(500, 100);
		/*	}
			catch(ArithmeticException ae)
			{
				System.out.println(ae.getMessage());
			}*/
			System.out.println("Finished Calling Calculate ....");
			System.out.println("Exiting Main....");
	}

}
