
public class ArrayException {

	
	public void manipulateArray()
	{
		int arr1[] = new int[10];
		System.out.println("We are about to manipulate Array..");
		System.out.println("We are populating and traversing an array");
		try
		{
			for(int i=0;i<=10;i++)
			{
				arr1[i]= (i+1)*10;
				System.out.println("The element is "+arr1[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException ae)
		{
			//System.out.println(ae);
			ae.printStackTrace();
		}
		System.out.println("We finished manipulating array...");
		System.out.println("We are exiting array function...");
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("About to  perform Array Manipulation ...");
		System.out.println("About to call Array Manipulation function...");
		try
		{
		ArrayException aex = new ArrayException();
		aex.manipulateArray();
		}
		catch(ArrayIndexOutOfBoundsException aix)
		{
			System.out.println(aix.getMessage());
		}
		System.out.println("finished  call to Array Manipulation function...");
		System.out.println("finished  performing Array Manipulation ...");
		
	}

}
