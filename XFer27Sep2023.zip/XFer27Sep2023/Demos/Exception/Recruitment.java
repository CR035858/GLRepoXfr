
public class Recruitment {
	
	public void checkAge(int age) throws InvalidAgeException
	{
		int score;
		
		if((age >= 20) &&(age <=30))
		{
			System.out.println("Valid Age...further scrutinization to continue..."+age);
		}
		else
		{
		//	InvalidAgeException iae = new InvalidAgeException("Sorry Valid Age is 20-30....");
			//Anonymous Objects
			throw new InvalidAgeException("Sorry Valid Age is 20-30....");
			
		}			
	}
	public void callCheckAge(int age)
	{
		System.out.println("Checking Age...");
		try
		{
			checkAge(age);
		}
		catch(InvalidAgeException iae)
		{
			//iae.printStackTrace();
			System.out.println(iae.message);
		}
		System.out.println("Age Check Over , to continue with further scrutiny...");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("In the Main ....");
		System.out.println("Recruitment Process atarted....");
		System.out.println("About to check age");
		Recruitment recruit = new Recruitment();
		/*try
		{*/
			recruit.callCheckAge(23);
			recruit.callCheckAge(25);
			recruit.callCheckAge(33);
			recruit.callCheckAge(24);
			recruit.callCheckAge(27);
		/*}
		catch(InvalidAgeException iae)
		{
			System.out.println(iae.message);
		}*/
		System.out.println("Age Scrutiny Completed...further process to continue....");

	}

}
