import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class ArrayListsStream {

	public void functional()
	{
		//Sum of squares of integers 1 to 5
		List <Integer> numbers = Arrays.asList(1,2,3,4,5);
		
		Stream <Integer> numberStream = numbers.stream();
		
		Stream <Integer> oddNumberStream = numberStream.filter(x -> x % 2 ==1);
		
		Stream <Integer> squaredNumberStream = oddNumberStream.map(x -> x * x);
		
		int sum = squaredNumberStream.reduce(0, (x,y) -> x + y);
		
		System.out.println("The sum of squares is "+sum);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayListsStream als = new ArrayListsStream();
		als.functional();
	}

}
