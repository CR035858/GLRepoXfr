import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FilteringOperations {

	public void filteringOperation()
	{
		IntStream.rangeClosed(1, 10)
					.filter( x -> x%2 == 0)
					.forEach(System.out::println);
	}
	public void filterProgrammers()
	{
		//Function <Programmer,String> getProgrammerName = p -> p.getName();
		
		//Predicate <Programmer> isFemaleProgrammer = p ->p.isFemale();
		
/*	Stream <String> progs1 = Programmer.programmers()
		.stream()
		.filter(Programmer::isFemale)
		.map(Programmer::getName);
	
	progs1.collect(Collectors.toList());*/
		
		Programmer.programmers()
					.stream()
					.filter(Programmer::isFemale)
					.map(Programmer::getName)
					.forEach(System.out::println);
	}
	public void multipleProgrammers()
	{
		Function <Programmer,String> getProgrammerName = p->p.getName();
		
		Predicate <Programmer> isMaleProgrammer = p->p.isMale();
		
		Predicate <Programmer> isEarningMoreThan5000 = p -> p.getIncome() > 5000;
		
		Predicate <Programmer> isMaleAndEarningMoreThan5000 = p -> p.isMale() && p.getIncome() > 5000;
		
		Programmer.programmers()
				 .stream()
				 .filter(isEarningMoreThan5000)
				 .filter(isMaleAndEarningMoreThan5000)
				 .filter(Programmer::isMale)
				 .map(Programmer :: getName)
				 .forEach(System.out::println);
				 
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FilteringOperations fop = new FilteringOperations();
	//	fop.filteringOperation();
	//	fop.filterProgrammers();
		fop.multipleProgrammers();

	}

}
