import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class LazyEagerOperation {

	public void functional()
	{
		List <Integer> numbers = Arrays.asList(1,2,3,4,5);
		
		Stream <Integer> stream = numbers.stream()
										.filter(LazyEagerOperation::oddNumber) // Lazy Op
										.map(LazyEagerOperation::square);
		
		int sum=0;
		sum = stream.reduce(0, LazyEagerOperation::sum); //Eager Op
		
		System.out.println("Functional : Sum of odd Numbers :"+sum);
		
	}
	static private boolean oddNumber(int number) {
		System.out.println("odd numbers called for "+number);
		return number % 2 == 1;
	}
	static int square(int number) {
		System.out.println("Square called for :"+number);
		return number * number;
	}
	
	static private int sum(int number1,int number2) {
		System.out.println("Sum called for "+number1+","+number2);
		return number1 + number2;
	}
	
	public static void main(String[] args)
	{
		LazyEagerOperation lep = new LazyEagerOperation();
		lep.functional();
	}
}
