package com.ford.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.function.AgentImplementation;
import com.ford.function.CustomerImplementation;
import com.ford.function.FunctionalImplementation;
import com.ford.function.ProductFilter;
import com.ford.function.ProductSortProductId;
import com.ford.function.ProductsSortProductName;

class FunctionalInterfaceTest {

	static FunctionalImplementation fImplement;
	static CustomerImplementation customerx;
	static AgentImplementation agentImplement;
	static ProductsSortProductName prodNameSort;
	static ProductSortProductId prodIdSort;
	static ProductFilter productFilter;
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		fImplement = new FunctionalImplementation();
		customerx = new CustomerImplementation();
		agentImplement = new AgentImplementation();
		prodNameSort = new ProductsSortProductName();
		prodIdSort = new ProductSortProductId();
		productFilter = new ProductFilter();
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	/*@Test
	void shouldImplementDisplay() {
		Assert.assertTrue(fImplement.implementDisplay());
	}
	
	@Test
	void shouldCalculatePrice() {
		int price = 10000;
		int qty = 4;
		Assert.assertEquals(40000, customerx.calculatePurchaseAmount(10000,4));
	}
	
	@Test
	void shouldGenerateDiscount() {
		Assert.assertEquals(10000.0, agentImplement.generateDiscount(10000, 10),0.0);
	}*/
	@Test
	void shouldSortProductName() {
		Assert.assertTrue(prodNameSort.sortProducts());
	}
	@Test
	void shouldSortProductId() {
		System.out.println("---------------");
		Assert.assertTrue(prodIdSort.sortProducts());
	}
	@Test
	void shouldFilterProductId() {
		System.out.println("---------------");
		Assert.assertTrue(productFilter.filterProductPrice());
	}

}
