package com.ford.function;

public class CustomerImplementation {
	
	public int calculatePurchaseAmount(int qty,int pricePUnit)
	{
		
		Customer customer1 = (int quantity,int price)->{
			return quantity * price;
		};
		
		int result = customer1.calculatePurchaseValue(qty, pricePUnit);
		return result;
	}

}
