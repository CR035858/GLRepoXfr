package com.ford.function;

import java.util.ArrayList;
import java.util.stream.Stream;

import com.ford.model.Product;

public class ProductFilter {
	ArrayList <Product> products = new ArrayList<Product>();
	public boolean filterProductPrice()
	{
		products.add(new Product("P002","Television",15000));
		products.add(new Product("P001","Refrigerator",25000));
		products.add(new Product("P003","BlueRayDisc",35000));
		products.add(new Product("P004","MacBook",150000));
		
		Stream <Product> productFilter = products.stream().filter(prod->prod.getPrice() >= 25000);
		productFilter.forEach(prod ->{System.out.println(prod);});
		return true;
	}

}
