package com.ford.function;

public interface MyFunctionalInterface {
	public void display();
}
