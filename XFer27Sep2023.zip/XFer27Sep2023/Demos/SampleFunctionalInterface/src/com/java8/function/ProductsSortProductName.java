package com.ford.function;

import java.util.ArrayList;
import java.util.Collections;

import com.ford.model.Product;

public class ProductsSortProductName {
	
	ArrayList <Product> products = new ArrayList<Product>();
	public boolean sortProducts()
	{
		products.add(new Product("P002","Television",15000));
		products.add(new Product("P001","Refrigerator",25000));
		products.add(new Product("P003","BlueRayDisc",35000));
		products.add(new Product("P004","MacBook",150000));
		//return p1.getProductName().compareTo(p2.getProductName());
		Collections.sort(products, (p1,p2) -> { 
			return p1.getProductName().compareTo(p2.getProductName());
			});
		
		for(Product p:products)
		{
			System.out.println(p);
		}
		return true;
	}

}
