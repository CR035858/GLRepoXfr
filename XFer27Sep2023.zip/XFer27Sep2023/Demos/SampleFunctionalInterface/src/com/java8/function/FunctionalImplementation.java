package com.ford.function;

public class FunctionalImplementation {
	
	public boolean implementDisplay()
	{
		// Implementation through Lambda Expression
		MyFunctionalInterface mInterface = () -> {
			System.out.println("Welcome to Functional Interfaces");
			System.out.println("We Implemented using Lambda Expression...");
		};
		
		// Invocation
		mInterface.display();
		return true;
		
	}
	
}
