package com.ford.function;

public class AgentImplementation {
	//public int calculateDiscount(int price,int qty,Customer c);
	public double generateDiscount(int costPrice,int quantity)
	{
		
		SalesAgent agent = (int price,int qt,Customer customer1) -> {
			double discount;
			int purchaseValue  = customer1.calculatePurchaseValue(price, qt);
			 discount =  purchaseValue * 0.1;
			return discount;
		};
		
		Customer cust1 = (int priceP,int qtyQ)->
		{
			return priceP * qtyQ;
		};
		double cDiscount  = agent.calculateDiscount(costPrice, quantity, cust1);
		return cDiscount;
	}

}
