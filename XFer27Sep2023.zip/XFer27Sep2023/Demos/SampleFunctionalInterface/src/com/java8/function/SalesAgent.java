package com.ford.function;

public interface SalesAgent {
	
	public double calculateDiscount(int price,int qty,Customer c);

}
