package com.ford.function;

public interface Customer {
	
	public int calculatePurchaseValue(int pricePerUnit,int quantity);

}
