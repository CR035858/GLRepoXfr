
public class Supplier {

	String supplierId;
	String supplierName;
	String supplierCity;
	int supplyValue;
	
	public Supplier() {
		super();
	}

	public Supplier(String supplierId, String supplierName, String supplierCity, int supplyValue) {
		super();
		this.supplierId = supplierId;
		this.supplierName = supplierName;
		this.supplierCity = supplierCity;
		this.supplyValue = supplyValue;
	}

	@Override
	public String toString() {
		return "Supplier [supplierId=" + supplierId + ", supplierName=" + supplierName + ", supplierCity="
				+ supplierCity + ", supplyValue=" + supplyValue + "]";
	}

	
	
	
	
}
