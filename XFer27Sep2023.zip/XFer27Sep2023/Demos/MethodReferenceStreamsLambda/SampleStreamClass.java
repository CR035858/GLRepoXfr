import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SampleStreamClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("----------------int Stream---------------------------");
		
		Stream <Integer> myStream1 = Stream.of(100,200,300,400,500);
		
		List <Integer> myIntList = myStream1.collect(Collectors.toList());
		System.out.println(myIntList);
		System.out.println("--------------------Integer Stream------------------------");
		Stream <Integer> myNewStream = Stream.of(new Integer[] {1000,2000,3000,4000,5000});
		
		List <Integer> myIntList1 = myNewStream.collect(Collectors.toList());
		System.out.println(myIntList1);
		System.out.println("--------------------ArrayList Stream---------------------");
		List <Integer> myAList = new ArrayList<Integer>();
		for(int i=0;i<100;i++)
		{
			myAList.add(i);
		}
		System.out.println("-----------------Sequential Stream of ArrayList Integer-------------");
		Stream <Integer> seqStream = myAList.stream();
		List <Integer> seqList  = seqStream.collect(Collectors.toList());
		System.out.println(seqList);
		System.out.println("-----------------Sequential Stream of ArrayList Integer-------------");
		Stream <Integer> parallelStream = myAList.parallelStream();
		
		List <Integer> paralList =  parallelStream.collect(Collectors.toList());
		
		System.out.println("-----------------------------------------");
		Stream <Integer> myStream = Stream.of(80,90,70,50,60,80,75,95,62,98,81);
		
		Integer nums[] = {800,200,700,400,500};
		
		//Transferring Stream to List
		List <Integer> myList = myStream.collect(Collectors.toList());
		System.out.println(myList);
		
		//Transferring from List to Stream
		Stream <Integer> myStream12 = myList.stream();
		
		//Stream.of(80,90,70,50,60,80,75,95,62,98,81);
		//Transferring Back to List
		List <Integer> myList1 = myStream12.collect(Collectors.toList());
		System.out.println(myList1);
		System.out.println("-----------------------------------------------");
		Stream <Integer> myStream2 = myList1.parallelStream();
		List <Integer> myList2 = myStream2.collect(Collectors.toList());
		System.out.println(myList2);
	/*	Stream <Integer> myStr2 = myStream2.sorted();*/
		
		System.out.println("----------Printing ----> 80 ---------");
		myList2.stream()
			   .filter(num -> num > 80)
			   .forEach(System.out::println);/**/
		System.out.println("-------------------Sorted--------------------");
		Stream <Integer> myStream3 = myList1.parallelStream();
		
	/*	Stream <Integer> myStr2 = myStream3.sorted();
		myStr2.forEach(System.out::println);*/
		myList1.stream()
				.sorted()
				.forEach(System.out::println);
		System.out.println("--------------Strings in UpperCase----------");
		List <String> myList3 =new ArrayList<String>();
		myList3.add("Dave");
		myList3.add("Raj");
		myList3.add("Kiran");
		myList3.add("Suman");
		myList3.add("Amar");
		myList3.add("Emanuel");
		
		myList3.stream()
			   .map(name -> name.toUpperCase())
			   .forEach(System.out::println);
		
	}

}
