package com.ford.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamClass {
	
	public List <Integer> getIntegers()
	{
		//int stream
		Stream <Integer> myStream = Stream.of(10,20,30,40,50,60,70,80,90,100);
		List <Integer> myList = myStream.collect(Collectors.toList());
		System.out.println(myList);
		return myList;
		
	}
	public List <Integer> getIntegersAgain()
	{
		Stream <Integer> myStream1 = Stream.of(new Integer[] {100,200,300,400,500});
		List <Integer> myList1 = myStream1.collect(Collectors.toList());
		System.out.println(myList1);
		return myList1;
	}
	public List <Integer> getSequentialStream()
	{
		List <Integer> myAlist = new ArrayList<Integer>();
		for(int i=0;i<5;i++)
		{
			myAlist.add(i);
		}
		Stream <Integer> seqStream = myAlist.stream();
		List <Integer> seqList = seqStream.collect(Collectors.toList());
		System.out.println(seqList);
	
		return seqList;
		
	}
	public List <Integer> getParallelStream()
	{
		List <Integer> myAlist = new ArrayList<Integer>();
		for(int i=0;i<5;i++)
		{
			myAlist.add(i);
		}
		Stream <Integer> seqStream = myAlist.parallelStream();
		List <Integer> parallelList = seqStream.collect(Collectors.toList());
		System.out.println(parallelList);
		return parallelList;
	}
	public List <Integer> getSortedList()
	{
		Stream <Integer> myStream1 = Stream.of(90,100,80,70,120,60,105,95,75,65);
		
		List <Integer> myList = myStream1.collect(Collectors.toList());
		
		Stream <Integer> backToParalStream = myList.parallelStream();
		
		
		
		Stream <Integer> parallelSortedStream = backToParalStream.sorted();
		
		List <Integer> mySortedList1 = parallelSortedStream.collect(Collectors.toList());
		System.out.println(mySortedList1);
		return mySortedList1;
	}
	
	public List <Integer> filteredList(int num1)
	{
		Stream <Integer> myStream1 = Stream.of(90,100,80,70,120,60,105,95,75,65);
		
		List <Integer> myList = myStream1.collect(Collectors.toList());
		
		Stream <Integer> backToParalStream = myList.parallelStream();
		
		
		
		Stream <Integer> parallelSortedStream = backToParalStream.sorted();
		
		List <Integer> mySortedList1 = parallelSortedStream.collect(Collectors.toList());
		System.out.println(mySortedList1);
		
		
		int x=num1;
		mySortedList1.stream()
				.filter(num -> num >= x)
				.forEach(System.out::println);
		
		return mySortedList1;
	}
	public List <String> getUpperCaseStrings()
	{
		List <String> myEmployees = new ArrayList<String>();
		myEmployees.add("Dave");
		myEmployees.add("Raj");
		myEmployees.add("Harsha");
		myEmployees.add("Emanuel");
		myEmployees.add("Ganesh");
		myEmployees.add("Mahendra");
		
		Stream <String> myStream1 =	myEmployees.stream() 
							.map(name -> name.toUpperCase());
		
		List <String> upperCaseStrList = myStream1.collect(Collectors.toList()); /**/
		
		myEmployees.stream() 
					.map(name -> name.toUpperCase())
					.forEach(System.out::println);
		
	return upperCaseStrList;
					
	}
	public static void main(String[] arg)
	{
		StreamClass sc = new StreamClass();
		sc.getUpperCaseStrings();
	}

}
