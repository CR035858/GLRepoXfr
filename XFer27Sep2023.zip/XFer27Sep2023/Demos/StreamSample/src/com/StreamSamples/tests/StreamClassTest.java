package com.ford.tests;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ford.streams.StreamClass;

class StreamClassTest {
	static StreamClass sClass;
	static List <Integer> sList;
	static List <Integer> sList1;
	static List <Integer> sList2;
	static List <Integer> sortedList;
	static List <Integer> sortFilteredList;
	static List <String> upperCaseStringList;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		sClass = new StreamClass();
		sList = new ArrayList<Integer>();
		sList1 = new ArrayList<Integer>();
		sList2 = new ArrayList<Integer>();
		sortedList = new ArrayList<Integer>();
		sortFilteredList = new ArrayList<Integer>();
		upperCaseStringList = new ArrayList<String>();
		//10,20,30,40,50,60,70,80,90,100
		sList.add(10);
		sList.add(20);
		sList.add(30);
		sList.add(40);
		sList.add(50);
		sList.add(60);
		sList.add(70);
		sList.add(80);
		sList.add(90);
		sList.add(100);
		
		sList1.add(100);
		sList1.add(200);
		sList1.add(300);
		sList1.add(400);
		sList1.add(500);
		
		sList2.add(0);
		sList2.add(1);
		sList2.add(2);
		sList2.add(3);
		sList2.add(4);
		//90,100,80,70,120,60,105,95,75,65
		
		sortedList.add(60);
		sortedList.add(65);
		sortedList.add(70);
		sortedList.add(75);
		sortedList.add(80);
		sortedList.add(90);
		sortedList.add(95);
		sortedList.add(100);
		sortedList.add(105);
		sortedList.add(120);
		
		
		sortFilteredList.add(90);
		sortFilteredList.add(95);
		sortFilteredList.add(100);
		sortFilteredList.add(105);
		sortFilteredList.add(120);
		
		
		
		upperCaseStringList.add("DAVE");
		upperCaseStringList.add("RAJ");
		upperCaseStringList.add("HARSHA");
		upperCaseStringList.add("EMANUEL");
		upperCaseStringList.add("GANESH");
		upperCaseStringList.add("MAHENDRA");
		
		
	
		
		
		
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

/*	@Test
	void shouldReturnList() {
		
		assertEquals(sList,sClass.getIntegers());
	}
	
	@Test
	void shouldReturnIntegerList() {
		
		assertEquals(sList1,sClass.getIntegersAgain());
	}

	@Test
	void shouldReturnSequentiaList() {
		
		assertEquals(sList2,sClass.getSequentialStream());
	}	
	@Test
	void shouldReturnParallelList() {
		
		assertEquals(sList2,sClass.getParallelStream());
	}
	
	@Test
	void shouldReturnSortedList() {
		assertEquals(sortedList,sClass.getSortedList());
	} 
	
	@Test
	void shouldReturnSortedFilteredList()
	{
		assertEquals(sortedList,sClass.filteredList(90));
	} */
	
	@Test
	void shouldReturnUpperCaseStrings()
	{
		assertEquals(upperCaseStringList,sClass.getUpperCaseStrings());
	} 

}
