package com.ford.lambda;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

 

public class ComparatorTest {
	static List<Address> addresses = new ArrayList<>();

	@BeforeClass
	public static void init() {
		
		addresses.add(new Address("123 Main St.", "Austin", "TX", "78787"));
		addresses.add(new Address("43 High St.", "Columbus", "OH", "43034"));
		addresses.add(new Address("678 Leon Rd.", "Tallahassee", "FL", "32307"));
		addresses.add(new Address("115 Howell Mill Rd", "Atlanta", "GA", "30318"));
		addresses.add(new Address("1050 Covington Hwy", "Macon", "GA", "30018"));
		addresses.add(new Address("1618 Sydenham St", "Philadelphia", "PA", "19141"));
		addresses.add(new Address("36 Deep Sea Way", "Boca Raton", "FL", "33433"));

	}

    // !! - Write an anonymous class to sort by state (alphabetically)
	@Test
	public void testAnonymous() {
        Collections.sort(addresses, new Comparator<Address>() {
            @Override
            public int compare(Address o1, Address o2) {
                return o1.getCity().compareTo(o2.getCity());
            }
        });
//        Comparator<Address> cityComparator = (o1,o2)-> o1.getCity().compareTo(o2.getCity());
//        Collections.sort(addresses,cityComparator);
        
        Assert.assertEquals("Atlanta", addresses.get(0).getCity());
        
	}
	
	 
	
	
	
}
