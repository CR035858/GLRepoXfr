package com.ford.methodreference;

import org.junit.Assert;
import org.junit.Test;

public class GenericMethodRefDemoTest {
	GenericMethodRefDemo genericMethodRefDemo = new GenericMethodRefDemo();

	@Test
	public void testIntCount() {
		Integer[] vals = { 1, 2, 3, 4, 2, 3, 4, 4, 5 };
		int count = genericMethodRefDemo.myOp(MyArrayOps::<Integer>countMatching, vals, 4);
		Assert.assertEquals(3, count);
	}

	@Test
	public void testStringCount() {
		String[] strs = { "One", "Two", "Three", "Two" };
		int count = genericMethodRefDemo.myOp(MyArrayOps::<String>countMatching, strs, "Two");
		Assert.assertEquals(2, count);
	}
}
