package com.ford.methodreference;

import org.junit.Assert;
import org.junit.Test;

interface MathOperation {
	int execute(int a, int b);
}

class Utils {
	public int calcu(int a, int b) {
		return a * b;
	}
}

public class InstanceMethodDemoTest {

	@Test
	public void test() {
		Utils utils = new Utils();
		MathOperation op = utils::calcu;
		Assert.assertEquals(80, op.execute(40, 2));
	}

}
