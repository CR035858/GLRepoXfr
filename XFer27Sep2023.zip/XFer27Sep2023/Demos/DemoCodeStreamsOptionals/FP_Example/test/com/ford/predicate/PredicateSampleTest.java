package com.ford.predicate;

import java.util.Arrays;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

class PredicateSampleTest {

	@Test
	void testPredicateForShorterWord() {
		PredicateSample<String> predicateFunc=t->t.length()>5;
		Assert.assertEquals(false, predicateFunc.test("Hello"));
	}

	@Test
	void testPredicateForLongerWord() {
		PredicateSample<String> predicateFunc=t->t.length()>5;
		Assert.assertEquals(true, predicateFunc.test("Hello World"));
	}

	@Test
	void testPredicateForFilter() {
		List <String> names=Arrays.asList("A","Hello World", "Foo", "Foo Bar");
		PredicateSample<String> predicateFunc=t->t.length()>5;
		Assert.assertEquals(true,names.stream().filter(n->predicateFunc.test(n)).count()==2 );
	}

	
	
}
