package com.ford.stream;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.junit.Ignore;
import org.junit.Test;

public class StreamTest {

	@Test
	public void testStreamFromArray() {
		IntStream intStream = Arrays.stream(new int[] { 1, 2, 3, 4, 5 });
		assertEquals(5, intStream.count());
	}

	@Test
	public void testStreamFromCollection() {

		List<String> strings = Arrays.asList("Hollis", "HollisChuang", "hollis", "Hello", "HelloWorld", "Hollis");
		Stream<String> stream = strings.stream();
		assertEquals(6, stream.count());
	}

	@Test
	public void testStreamFromFile() {
		StreamsFromFiles streamsFromFiles = new StreamsFromFiles();
		long fileLineSize = streamsFromFiles.readFile("src/com/ford/stream/StreamsFromFiles.java");
		assertEquals(37, fileLineSize);
	}

	@Test
 	public void testInifiniteStreamUsingIterate() {
		Stream<Long> singleStream = Stream.iterate(1L, n -> n + 1);
 
		singleStream.forEach(System.out::println);
	}

	@Test
	@Ignore
	public void testInifiniteStreamUsingGenerate() {
		Stream<Double> doubleStream = Stream.generate(Math::random);
		doubleStream.forEach(System.out::println);
	}

	@Test
	public void testEmptyStream() {
		Stream<String> singleStream = Stream.empty();
		singleStream.forEach(System.out::println);
	}

	@Test
	public void testParallelStreamUsingIterate() {
		IntStream range2 = IntStream.rangeClosed(1, 10);
		range2.parallel().forEach(System.out::println);

	}

	@Test
	public void testStreamBuild() {
		Stream.Builder<String> builder = Stream.<String>builder();
		Stream<String> stream = builder.add("london").add("Paris").add("Zurich").build();
		stream.forEach(System.out::println);
	}
}
