package com.ford.lambda;

public class RunnableTest {

	// !! - Write an anonymous Runnable class here
    //It can just print out "Anonymous run" or similar
     
}
