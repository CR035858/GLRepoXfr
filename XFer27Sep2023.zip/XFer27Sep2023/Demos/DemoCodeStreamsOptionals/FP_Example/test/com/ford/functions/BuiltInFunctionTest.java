package com.ford.functions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;

import org.junit.Test;

public class BuiltInFunctionTest {

	@Test
	public void testConsumer() {

		Consumer<String> consumer = new Consumer<String>() {

			@Override
			public void accept(String name) {
		
				System.out.println("Hello "+name);

			}
			
		};
		consumer.accept("Sameer");
	}
	
	@Test
	public void testSupplier() {
		Supplier<String> supplier=new Supplier<String>() {
			@Override
			public String get() {
				return "HHHH";
			}
		};
		
		Supplier<String> supplier2=()->"hhhhh2";
		 Predicate predicate=new Predicate<Integer>() {

			@Override
			public boolean test(Integer t) {
				// TODO Auto-generated method stub
				return false;
			}
		};
		
		@SuppressWarnings("rawtypes")
		Predicate predicate3=(n)->{
			System.out.println("Check for validity");
			return true;
			};
		System.out.println("Random Value"+supplier2.get());
	}



 
	
}
