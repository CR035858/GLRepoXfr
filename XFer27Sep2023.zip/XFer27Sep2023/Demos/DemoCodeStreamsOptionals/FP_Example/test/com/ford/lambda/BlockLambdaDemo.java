package com.ford.lambda;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
 

interface SomeFunc<T> {
	T func(T n);

};

public class BlockLambdaDemo {

	@Test
	public void testFactorial() {
		SomeFunc<Integer> factorial = (n) -> {
			int result = 1;
			for (int i = 1; i <= n; i++)
				result = i * result;
			return result;
		};
		Integer func = factorial.func(3);
		assertEquals(9, func.intValue());
 	}

//	@Test
//	public void testStringReverse() {
//
//
//	}
	
	
	static <T> T someOperation(SomeFunc<T> s, T value) {
		return s.func(value);
	}

}
