package com.ford.functions;

import org.junit.Assert;
import org.junit.Test;

public class FunctionalInterfaceExampleTest {

	@Test
	public void testAdd() {
			FunctionalInterfaceExample fie = new FunctionalInterfaceExample();  
	        int result = fie.add(10, 20);
	        Assert.assertEquals(30, result);
	}

}
