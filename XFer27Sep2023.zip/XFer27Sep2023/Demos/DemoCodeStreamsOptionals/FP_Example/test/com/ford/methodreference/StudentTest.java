package com.ford.methodreference;

import org.junit.Test;

interface StudentsGenerator {
	public Student create();
}

public class StudentTest {

	@Test
	public void testConstructorReference() {
		Student []students = new Student[8];
		populate(students, Student::new);
		for(int i=0; i<students.length; i++) {
		System.out.println(students[i]);
		}
	}

	public static void populate(Student[] vec, StudentsGenerator ob) {
		for (int i = 0; i < vec.length; i++) {
			vec[i] = ob.create();
		}
	}
}
