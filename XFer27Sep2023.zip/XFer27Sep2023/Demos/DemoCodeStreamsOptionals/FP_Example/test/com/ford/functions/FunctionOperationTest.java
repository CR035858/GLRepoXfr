package com.ford.functions;

import java.util.function.Function;

import org.junit.Assert;
import org.junit.Test;

public class FunctionOperationTest {
	Function<Integer, Integer> multiply = (value) -> value * 2;
	Function<Integer, Integer> add      = (value) -> value + 3;

	@Test
	public void testComposition() {
		Function<Integer, Integer> addThenMultiply = multiply.compose(add);
		Assert.assertEquals(12,  addThenMultiply.apply(3).intValue());
	}

	@Test
	public void testChainingComposition() {
		Function<Integer, Integer> addThenMultiply = multiply.andThen(add);
		Assert.assertEquals(9,  addThenMultiply.apply(3).intValue());
	}
}
