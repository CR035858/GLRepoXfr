package com.ford.methodreference;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
 

public class InstanceMethodWithObjectRefDemoTest {

	InstanceMethodWithObjectRefDemo instanceRefDemo=new InstanceMethodWithObjectRefDemo();
	HighTemp[] weekDayHighs = { new HighTemp(89), new HighTemp(82), new HighTemp(90), new HighTemp(89),
			new HighTemp(89), new HighTemp(91), new HighTemp(84), new HighTemp(83) };

	@Test
	public void testSameTemperature() {
		int count;
		count = instanceRefDemo.counter(weekDayHighs, HighTemp::sameTemp, new HighTemp(89));
 		assertEquals(3, count);
  	}

	@Test
	public void testLessThanTemperature() {
		int count;
 		count = instanceRefDemo.counter(weekDayHighs, HighTemp::lessThanTemp, new HighTemp(84));
 		assertEquals(2, count);
	}

	
}
