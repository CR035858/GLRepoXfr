package com.ford.predicate;

import java.util.function.Predicate;

import org.junit.Test;

public class PredicateTestFeatures {
	Predicate<Integer> p = number -> (number % 2 == 0);
	Predicate<Integer> p1 = number -> (number > 10);

	@Test
	public void testFeatures() {
		// test()
		System.out.println(p.test(10));// true
		// negate()
		System.out.println(p.negate().test(10));// false
		// and()
		System.out.println(p.and(p1).test(10));// false
		System.out.println(p.and(p1).test(12));// true
		// or()
		System.out.println(p.or(p1).test(10));// true
		System.out.println(p.or(p1).test(11));// true
		System.out.println(p.or(p1).test(9));// false
		// isequal()
		System.out.println(Predicate.isEqual("Satish").test("Varma"));// false
		System.out.println(Predicate.isEqual("Satish").test("Satish"));// true
	}

}