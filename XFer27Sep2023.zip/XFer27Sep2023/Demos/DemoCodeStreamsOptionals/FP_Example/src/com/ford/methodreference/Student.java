package com.ford.methodreference;

class Student implements Comparable<Student> {
	private static int counter = 1;
	private static String[] names = { "david", "moshe", "anat", "jake" };
	private double average;
	private int id;
	private String name;

	Student() {
		id = counter++;
		name = names[(int) (names.length * Math.random())];
		average = (int) (100 * Math.random());
	}

	Student(int id, double avg, String name) {
		this.average = avg;
		this.id = id;
		this.name = name;
	}

	@Override
	public String toString() {
		return id + " " + average + " " + name;
	}

	@Override
	public int compareTo(Student o) {
		if (this.average > o.average) {
			return 1;
		} else if (this.average < o.average) {
			return -1;
		} else
			return 0;
	}
}