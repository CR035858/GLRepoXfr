package com.ford.functions;

@FunctionalInterface  
interface AddInterface{  
    int add(int a, int b);  
     
}  
 
public class FunctionalInterfaceExample implements AddInterface {
	public int add(int a, int b){  
        return (a+b);  
    } 
	
}