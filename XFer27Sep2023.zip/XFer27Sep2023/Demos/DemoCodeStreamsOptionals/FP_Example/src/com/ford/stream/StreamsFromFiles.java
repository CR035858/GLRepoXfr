package com.ford.stream;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class StreamsFromFiles {

	public long readFile(String filePath) {

		Path path = Paths.get(filePath);

		if (!Files.exists(path)) {
			System.out.println("The file " + path.toAbsolutePath() + " doesn't exist.");
			return -1;
		}
		long lineCount = 0;
		Stream<String> lines;
		try {
			lines = Files.lines(path);
			lineCount = lines.count();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return lineCount;

	}

	public static void main(String... args) {

		StreamsFromFiles streamsFromFiles = new StreamsFromFiles();
		streamsFromFiles.readFile("src/com/manvendrask/creatingstreams/StreamsFromFiles.java");
	}
}
