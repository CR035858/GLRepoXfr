package com.ford.predicate;

@FunctionalInterface
public interface PredicateSample<T> {
	boolean test (T t);
}
