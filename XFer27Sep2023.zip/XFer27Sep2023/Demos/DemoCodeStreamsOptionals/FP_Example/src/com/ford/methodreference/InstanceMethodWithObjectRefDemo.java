package com.ford.methodreference;

interface MyFunc<T> {
	boolean func(T v1, T v2);
}

class HighTemp {
	private int hTemp;

	public HighTemp(int ht) {
		hTemp = ht;
	}

	// Return true if the invoking HighTemp object has the same temperature as ht2.
	boolean sameTemp(HighTemp ht2) {
		return hTemp == ht2.hTemp;
	}

	// Return true if the invoking HighTemp object has a temperature that is less
	// than ht2.
	boolean lessThanTemp(HighTemp ht2) {
		return hTemp < ht2.hTemp;
	}

}


public class InstanceMethodWithObjectRefDemo {
	// A method that returns the number of occurrences of an object for which some
	// criteria, as specified by the MyFunc
	// parameter, is true.
	<T> int counter(T[] vals, MyFunc<T> f, T v) {
		int count = 0;
		for (int i = 0; i < vals.length; i++)
			if (f.func(vals[i], v))
				count++;
		return count;
	}

}