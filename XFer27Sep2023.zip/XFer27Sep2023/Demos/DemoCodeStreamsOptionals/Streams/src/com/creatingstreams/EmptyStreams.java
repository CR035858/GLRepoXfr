package com.creatingstreams;

import java.util.stream.Stream;


public class EmptyStreams {

    void emptyStream() {
        Stream<String> singleStream = Stream.empty();
        singleStream.forEach(System.out::println);
    }


    public static void main(String... args) {

        EmptyStreams streamFromValues = new EmptyStreams();
        streamFromValues.emptyStream();
    }
}
