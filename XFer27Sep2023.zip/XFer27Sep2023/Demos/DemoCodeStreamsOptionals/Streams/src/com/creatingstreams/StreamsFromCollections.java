package com.creatingstreams;

import java.util.HashSet;
import java.util.Set;


public class StreamsFromCollections {

    void createStringStream() {

        Set<String> pronouns = new HashSet<>();
        pronouns.add("I");
        pronouns.add("Me");
        pronouns.add("You");

        pronouns.stream().forEach(System.out::println);
    }


    public static void main(String... args) {

        StreamsFromCollections streamsFromCollections = new StreamsFromCollections();
        streamsFromCollections.createStringStream();
    }
}
