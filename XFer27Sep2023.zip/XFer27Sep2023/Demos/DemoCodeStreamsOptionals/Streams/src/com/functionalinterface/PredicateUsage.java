package com.functionalinterface;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class PredicateUsage {
    public static void main(String[] args) {
        Predicate<String> predicate=new Predicate<String>(){
            @Override
            public boolean test(String s) {
                return s.equals("Mathew") ? true :false;
            }
        };
        List<String> names= Arrays.asList("Jack","Mathew","Ken");
        for (String name:names){
            if(predicate.test(name)){
                System.out.println("We have Mathew on the list");
            }
        }
    }
}
