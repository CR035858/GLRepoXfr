package com.main;

import com.whatarestreams.EagerAndLazy;
import com.whatarestreams.ImperativeVsFunctional;
import com.whatarestreams.ReusingStreams;
import com.whatarestreams.UnderstandingStreams;


public class Main {

    public static void main(String... args) {
        ImperativeVsFunctional imperativeVsFunctional = new ImperativeVsFunctional();

        imperativeVsFunctional.imperative();
        imperativeVsFunctional.functional();

        EagerAndLazy eagerAndLazy = new EagerAndLazy();
        eagerAndLazy.functional();

        ReusingStreams reusingStreams = new ReusingStreams();
        reusingStreams.functional();

        UnderstandingStreams understandingStreams = new UnderstandingStreams();
        understandingStreams.functional();


    }
}
