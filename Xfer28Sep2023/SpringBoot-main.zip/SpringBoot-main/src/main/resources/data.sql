
insert into library values (1, 'learn java, learn scala, learn aws','Techn library');
insert into library values (2, 'Mars Red Planet, Titan with water','Space library');
insert into library values (3, 'learn python, learn scala, learn aws','Technology library');
insert into library values (4, 'Mars Blue Planet, Titan with water','Moon library');
insert into library values (5, 'Yellow sun, Blue star, Red stars','Star library');
insert into library values (6, 'Yellow sun, Blue star, Red stars', 'Dog library');
insert into library values (7, 'xyz, abc, efg','A library');
insert into library values (8, 'xyz, abc, efg','B library');


